#!/bin/bash

# General Options
export JAVA_HOME=/usr/lib/jvm/java
export LENA_MANAGER_ADDRESS=172.31.1.18:7700
export LENA_CLUSTER_NAME=cluster
export LENA_USER=lena
export LENA_GROUP=lena

export LENA_WAS_SCALING=Y
export LENA_WAS_HOME=/engn001/lena/1.3
export LENA_WAS_AGENT_PORT=16800

export LENA_WEB_SCALING=Y
export LENA_WEB_HOME=/engn001/lenaw/1.3
export LENA_WEB_AGENT_PORT=16900

# LENA_IMAGE_TYPE
# golen   | LENA Golden Image (with servers installed and *MOST OF THE SETTING CONFIGURED*) is used in LENA_SCALING_MODE "Sync | Nosync".
# base    | LENA Base Image (including only packages without server installed) is used in LENA_SCALING_MODE "Clone".
export LENA_IMAGE_TYPE=golden

# WAS_CONFIG_DATA
# You can change manually Service Endpoint, Session cluster, Datasource if required.
# **IMPORTANT** Linux package 'jq', "xmlstarlet" must be installed.
# **CAUTION** JSON validation check isn't perfect. Incorrect JSON format or data can cause malfunction.
# Do not declare an elements unless you modify them.
# This is ignored when LENA_SCLAING_MODE is "clone".
# Also, this is overwritten with "cluster config" when LENA_SCALING_MODE is "sync" and there is "cluster config" in the server cluster.
#
#         *Element*                *Type*      *Key Element*              *Comment*
# +--------------------------+---------------+---------------+----------------------------------------------
# | server_id                | string        |     true      | Server ID is matched with directory name under $LENA_HOME/servers/
# +--------------------------+---------------+---------------+----------------------------------------------
# | service_endpoint         | String        |     false     | Endpoint URL representing WAS access.
# |                          |               |               | Format - Protocol://Address(LB/DNS):Port
# +--------------------------+---------------+---------------+----------------------------------------------
# | session_cluster          | objects {}    |     false     |
# +-+------------------------+---------------+---------------+----------------------------------------------
# | | primary_host           | ip | domain   |     false     | IPv4 or Domain Name is available
# | | primary_port           | port          |     false     |
# | | secondary_host         | ip | domain   |     false     | IPv4 or Domain Name is available
# | | secondary_port         | port          |     false     |
# +-+------------------------+---------------+---------------+----------------------------------------------
# | datasource               | arrays []     |     false     |
# +-+-+----------------------+---------------+---------------+----------------------------------------------
# | | | jndi_name            | string        |     true      | Datasource can be changed only if JNDI Name is matched.
# | | | url                  | string        |     false     | The url should be a complete full string with jdbc parameters.
# | | | username             | string        |     false     |
# | | | password             | string        |     false     | Encrypted passwords can be obtained from LENA MANAGER
# | | | passwordEncrypted    | true | false  |     false     | If set true, password has to be encrypted string
# +-+-+----------------------+---------------+---------------+----------------------------------------------
#
# === SAMPLE DATA ====
# export WAS_CONFIG_DATA='[
#     {
#         "server_id": "se-8180",
#         "service_endpoint": "http://endpoint_address:http_port",
#         "session_cluster": {
#             "primary_host": "172.31.1.18",
#             "secondary_host": "172.31.1.18",
#         },
#         "datasource": [
#             {
#                 "jndi_name": "jdbc/petclinic",
#                 "url": "jdbc:mariadb://datasource_address:port/database_name",
#                 "password": "lena01"
#                 "passwordEncrypted": "false"
#             }
#         ]
#     }
# ]'
export WAS_CONFIG_DATA=


# WEB_CONFIG_DATA
# You can change manually Proxy Target Address if required.
# **IMPORTANT** Linux package 'jq' must be installed.
# **CAUTION** JSON validation check isn't perfect. Incorrect JSON format or data can cause malfunction.
# Do not declare elements unless you modify them.
# This is ignored when LENA_SCLAING_MODE is "clone".
# Also, this is overwritten with "cluster config" when LENA_SCALING_MODE is "sync" and there is "cluster config" in the server cluster.
#
#         *Element*                *Type*      *Key Element*              *Comment*
# +--------------------------+---------------+---------------+----------------------------------------------
# | server_id                | string        |     true      | Server ID is matched with directory name under $LENA_HOME/servers/
# +--------------------------+---------------+---------------+----------------------------------------------
# | vhost                    | arrays []     |     false     | Virtual Host list in Web Server
# +-+------------------------+---------------+---------------+----------------------------------------------
# | | vhost_name             | string        |     true      | Virtual Host name
# | | proxy                  | arrays []     |     false     | Proxy Pass Match Rules for HTTP Connector
# +-+-+----------------------+---------------+---------------+----------------------------------------------
# | | | match_exp            | reg expr      |     true      | Proxy Pass Match Rule in regular expression
# | | | target_address       | string        |     false     | Proxy Pass Target Address
# | | |                      |               |               | Format - Protocol://Address(LB/DNS):Port
# +-+-+----------------------+---------------+---------------+----------------------------------------------
# | | proxy_ssl              | arrays []     |     false     | Proxy Pass Match Rules for HTTPS Connector
# +-+-+----------------------+---------------+---------------+----------------------------------------------
# | | | match_exp            | reg expr      |     true      | Proxy Pass Match Rule in regular expression
# | | | target_address       | string        |     false     | Proxy Pass Target Address
# | | |                      |               |               | Format - Protocol://Address(LB/DNS):Port
# +-+-+----------------------+---------------+---------------+----------------------------------------------
#
# === SAMPLE DATA ====
# export WEB_CONFIG_DATA='[
#     {
#         "server_id": "web-7180",
#         "vhost": [
#             {
#                 "vhost_name": "vhost_default",
#                 "proxy": [
#                     {
#                         "match_exp": "^/(.*\.(jsp|do))$",
#                         "target_address": "http://endpoint_address:http_port"
#                     }
#                 ],
#                 "proxy_ssl": [
#                     {
#                         "match_exp": "^/(.*\.(jsp|do))$",
#                         "target_address": "https://endpoint_address:https_port"
#                     }
#                 ]
#             }
#         ]
#     }
# ]'
export WEB_CONFIG_DATA=



if [ "$LENA_WAS_SCALING" = "Y" ]; then $LENA_WAS_HOME/bin/scale.sh; fi
if [ "$LENA_WEB_SCALING" = "Y" ]; then $LENA_WEB_HOME/bin/scale.sh; fi


# If you want to save Scaling Init Script, follow the steps below.
# Then that you can reuse this script to scale out again.
#
# 1. Save init script to init-userdata.sh file.
# 2. Run init-userdata.sh
#
# Notice. Variables in area of "cat << EOF ... EOF" must be escaped with '\' character.
# +--------------------------------------------------------------------------+
# | #!/bin/bash                                                              |
# |                                                                          |
# | cat << EOF > /root/init-userdata.sh                                      |
# | ...                                                                      |
# | << Whole Content of Init Script >>                                       |
# | if [ "\$LENA_WAS_SCALING" = "Y" ]; then \$LENA_WAS_HOME/bin/scale.sh; fi |
# | if [ "\$LENA_WEB_SCALING" = "Y" ]; then \$LENA_WEB_HOME/bin/scale.sh; fi |
# | EOF                                                                      |
# |                                                                          |
# | sh /root/init-userdata.sh                                                |
# +--------------------------------------------------------------------------+